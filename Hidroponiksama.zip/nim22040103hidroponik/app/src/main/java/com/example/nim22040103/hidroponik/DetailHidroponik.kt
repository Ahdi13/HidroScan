package com.example.nim22040103.hidroponik

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.ByteArrayOutputStream


class DetailHidroponik : AppCompatActivity() {
    companion object {
        const val EXTRA_NAMA = "extra_nama"
        const val EXTRA_GAMBAR = "extra_GAMBAR"
        const val EXTRA_KETERANGAN = "extra_keterangan"
        const val EXTRA_TIPE= "extra_tipe"
        const val EXTRA_BBAKAR = "extra_BahanBakar"
    }

    private lateinit var namaHidroponikDetail: TextView
    private lateinit var gambarHidroponikDetail: ImageView
    private lateinit var keteranganHidroponikDetail: TextView
    private lateinit var tipeHidroponikDetail: TextView
    private lateinit var bbakarHidroponikDetail: TextView
    private lateinit var shareButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail_hidroponik)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        namaHidroponikDetail = findViewById(R.id.tv_Detail_namaHidroponik)
        gambarHidroponikDetail = findViewById(R.id.iv_detail_gambarHidroponik)
        keteranganHidroponikDetail = findViewById(R.id.tv_Detail_keteranganHidroponik)
        tipeHidroponikDetail = findViewById(R.id.tv_Detail_tipe)
        bbakarHidroponikDetail = findViewById(R.id.tv_Detail_bbakar)
        shareButton = findViewById(R.id.btn_share_hidroponik_detail)

        val terimaNama = intent.getStringExtra(EXTRA_NAMA)
        val terimaGambar = intent.getIntExtra(EXTRA_GAMBAR, 0)
        val terimaKeterangan = intent.getStringExtra(EXTRA_KETERANGAN)
        val terimaTipe = intent.getStringExtra(EXTRA_TIPE)
        val terimaBbakar = intent.getStringExtra(EXTRA_BBAKAR)

        namaHidroponikDetail.text = terimaNama
        gambarHidroponikDetail.setImageResource(terimaGambar)
        keteranganHidroponikDetail.text = terimaKeterangan
        tipeHidroponikDetail.text = terimaTipe
        bbakarHidroponikDetail.text = terimaBbakar

        shareButton.setOnClickListener {
            shareHidroponikDetails(terimaNama, terimaGambar, terimaKeterangan, terimaTipe, terimaBbakar)
        }
    }

    private fun shareHidroponikDetails(nama: String?, gambar: Int, keterangan: String?, tipe: String?, bbakar: String?) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Hidroponik Details:\n\nName: $nama\nDescription: $keterangan\nTipe: $tipe\nAbility: $bbakar")
            type = "text/plain"
        }

        // Check if image is not null and add it to shareIntent
        if (gambar != 0) {

            val bitmap = (gambarHidroponikDetail.drawable as BitmapDrawable).bitmap
            val bytes = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
            val path = MediaStore.Images.Media.insertImage(contentResolver, bitmap, "Car Image", null)
            val uri = Uri.parse(path)
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri)
            shareIntent.type = "image/*"
        }

        startActivity(Intent.createChooser(shareIntent, "Share Car Details"))
    }

}
