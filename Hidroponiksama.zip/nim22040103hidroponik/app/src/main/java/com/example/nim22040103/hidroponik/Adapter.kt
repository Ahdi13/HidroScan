package com.example.nim22040103.hidroponik

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter(private val hidroponikList: ArrayList<Hidroponikdb>) : RecyclerView.Adapter<Adapter.ListViewHolder>() {

    // Deklarasi callback untuk item klik
    private var onItemClickCallback: OnItemClickCallback? = null

    // Fungsi untuk mengatur callback
    fun setOnItemClickCallback(callback: OnItemClickCallback) {
        this.onItemClickCallback = callback
    }

    // Membuat ViewHolder untuk item RecyclerView
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_adapter, parent, false)
        return ListViewHolder(view)
    }

    // Mengikat data ke ViewHolder
    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val hidroponik = hidroponikList[position]
        holder.apply {
            imageHidroponik.setImageResource(hidroponik.gambarHidroponik)
            nameHidroponik.text = hidroponik.namaHidroponik
            descriptionHidroponik.text = hidroponik.keteranganHidroponik

            // Menangani klik item
            itemView.setOnClickListener {
                onItemClickCallback?.onItemClicked(hidroponik)
            }

        }
    }

    // Mengembalikan jumlah item
    override fun getItemCount(): Int = hidroponikList.size

    // ViewHolder untuk setiap item
    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageHidroponik: ImageView = itemView.findViewById(R.id.img_item_hidroponik_list)
        val nameHidroponik: TextView = itemView.findViewById(R.id.tv_nama_hidroponik_list)
        val descriptionHidroponik: TextView = itemView.findViewById(R.id.tv_keterangan_hidroponik_list)
    }

    // Interface untuk menangani klik item
    interface OnItemClickCallback {
        fun onItemClicked(data: Hidroponikdb)
        fun onShareClicked(data: Hidroponikdb)
    }
}
 