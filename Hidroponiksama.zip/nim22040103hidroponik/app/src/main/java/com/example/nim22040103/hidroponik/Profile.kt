package com.example.nim22040103.hidroponik

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.nim22040103.hidroponik.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Cek dan minta izin akses penyimpanan jika diperlukan
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        } else {
            loadUserData()
        }

        binding.saveButton.setOnClickListener {
            saveUserProfile()
        }
    }

    private fun loadUserData() {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            database.child("users").child(uid).get().addOnSuccessListener { snapshot ->
                val name = snapshot.child("name").value as? String
                val email = snapshot.child("email").value as? String

                binding.nameEditText.setText(name)
                binding.emailEditText.setText(email)
            }
        }
    }

    private fun saveUserProfile() {
        val name = binding.nameEditText.text.toString().trim()
        val email = auth.currentUser?.email ?: return
        val uid = auth.currentUser?.uid ?: return

        if (name.isEmpty()) {
            binding.nameEditText.error = "Nama tidak boleh kosong"
            return
        }

        val userMap = mapOf(
            "name" to name,
            "email" to email
        )

        database.child("users").child(uid).updateChildren(userMap)
            .addOnSuccessListener {
                Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadUserData()
            } else {
                Toast.makeText(this, "Izin akses penyimpanan ditolak", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
