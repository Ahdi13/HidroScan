package com.example.nim22040103.hidroponik;

public interface ResponsCallback {

    void onResponse(String response);
    void onError(Throwable throwble);

}
