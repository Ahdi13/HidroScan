package com.example.nim22040103.hidroponik

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.nim22040103.hidroponik.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        binding.continueBtn.setOnClickListener {
            val email = binding.email.text.toString().trim()
            val password = binding.password.text.toString().trim()

            // Validasi email kosong
            if (email.isEmpty()) {
                binding.email.error = "Email tidak boleh kosong"
                binding.email.requestFocus()
                return@setOnClickListener
            }

            // Validasi format email
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.email.error = "Format email tidak valid"
                binding.email.requestFocus()
                return@setOnClickListener
            }

            // Validasi password kosong
            if (password.isEmpty()) {
                binding.password.error = "Password tidak boleh kosong"
                binding.password.requestFocus()
                return@setOnClickListener
            }

            // Validasi panjang password minimal 6 karakter
            if (password.length < 6) {
                binding.password.error = "Password minimal 6 karakter"
                binding.password.requestFocus()
                return@setOnClickListener
            }

            // Daftar user baru ke Firebase
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "createUserWithEmail:success")

                        // Pindah ke Monitoring activity
                        val intent = Intent(this, Monitoring::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Log.w(TAG, "createUserWithEmail:failure", task.exception)

                        Toast.makeText(
                            this,
                            "Registrasi gagal: ${task.exception?.localizedMessage ?: "Coba lagi nanti."}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
        }

        // Pindah ke LoginActivity kalau user udah punya akun
        binding.move.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    // Auto-masuk kalau sudah login sebelumnya
    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            startActivity(Intent(this, Monitoring::class.java))
            finish()
        }
    }
}
