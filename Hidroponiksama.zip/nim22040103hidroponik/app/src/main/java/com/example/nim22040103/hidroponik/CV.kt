package com.example.nim22040103.hidroponik

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class CV : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cv)

        val shareButton: Button = findViewById(R.id.share_button)
        val ivWhatsApp: ImageView = findViewById(R.id.idwa)
        val ivInstagram: ImageView = findViewById(R.id.idinsta)
        val ivFacebook: ImageView = findViewById(R.id.idfb)
        val ivGitHub: ImageView = findViewById(R.id.idgithub)

        // Tombol share untuk gambar
        shareButton.setOnClickListener {
            val scrollView = findViewById<ScrollView>(R.id.scrollView)
            val bitmap = captureScrollView(scrollView)
            val file = saveBitmapToFile(bitmap)

            if (file != null) {
                shareImage(file)
            }
        }

        // Event listener untuk WhatsApp
        ivWhatsApp.setOnClickListener {
            openSocialMedia("https://wa.me/+6289647719232") // Ganti dengan nomor WhatsApp Anda
        }

        // Event listener untuk Instagram
        ivInstagram.setOnClickListener {
            openSocialMedia("https://www.instagram.com/ahdick_") // Ganti dengan akun Instagram Anda
        }

        // Event listener untuk Facebook
        ivFacebook.setOnClickListener {
            openSocialMedia("https://www.facebook.com/nukata.alfaz") // Ganti dengan akun Facebook Anda
        }

        // Event listener untuk GitHub
        ivGitHub.setOnClickListener {
            openSocialMedia("https://github.com/Ahdi13") // Ganti dengan akun GitHub Anda
        }
    }

    // Fungsi untuk menangkap ScrollView sebagai gambar
    private fun captureScrollView(scrollView: ScrollView): Bitmap {
        val height = scrollView.getChildAt(0).height
        val width = scrollView.width
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        scrollView.draw(canvas)
        return bitmap
    }

    // Fungsi untuk menyimpan Bitmap ke file
    private fun saveBitmapToFile(bitmap: Bitmap): File? {
        val file = File(externalCacheDir, "shared_hidroponik_image.png")
        try {
            FileOutputStream(file).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }
            return file
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }
    }

    // Fungsi untuk membagikan gambar
    private fun shareImage(file: File) {
        val fileUri = FileProvider.getUriForFile(
            this,
            "${packageName}.provider",
            file
        )

        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, fileUri)
            type = "image/png"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Bagikan gambar hidroponik menggunakan"))
    }

    // Fungsi untuk membuka aplikasi media sosial
    private fun openSocialMedia(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
        startActivity(intent)
    }
}
