package com.example.nim22040103.hidroponik

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class About : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        val shareButton: Button = findViewById(R.id.share_button)

        shareButton.setOnClickListener {
            val scrollView = findViewById<ScrollView>(R.id.scrollView)
            val bitmap = captureScrollView(scrollView)
            val file = saveBitmapToFile(bitmap)

            if (file != null) {
                shareImage(file)
            }
        }
    }

    private fun captureScrollView(scrollView: ScrollView): Bitmap {
        val height = scrollView.getChildAt(0).height
        val width = scrollView.width
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        scrollView.draw(canvas)
        return bitmap
    }

    private fun saveBitmapToFile(bitmap: Bitmap): File? {
        val file = File(externalCacheDir, "shared_image.png")
        try {
            FileOutputStream(file).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }
            return file
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }
    }

    private fun shareImage(file: File) {
        val fileUri = FileProvider.getUriForFile(
            this,
            "${packageName}.provider",
            file
        )

        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, fileUri)
            type = "image/png"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Bagikan gambar menggunakan"))
    }
}