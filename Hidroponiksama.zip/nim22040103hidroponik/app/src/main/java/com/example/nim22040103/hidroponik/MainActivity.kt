package com.example.nim22040103.hidroponik


import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var rvHidroponik: RecyclerView
    private val list = ArrayList<Hidroponikdb>()
    private lateinit var listAdapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.drawer_layout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        rvHidroponik = findViewById(R.id.rv_Hidroponik)
        rvHidroponik.setHasFixedSize(true)

        list.addAll(getListHidroponik())
        listAdapter = Adapter(list)
        showRecyclerList()


    }

    private fun getListHidroponik(): ArrayList<Hidroponikdb> {
        val dataName = resources.getStringArray(R.array.name_hidroponik)
        val dataPhoto = resources.obtainTypedArray(R.array.gambar_hidroponik)
        val dataKet = resources.getStringArray(R.array.Keterangan_hidroponik)
        val dataTipe = resources.getStringArray(R.array.tipe)
        val dataBbakar = resources.getStringArray(R.array.keterangan)
        val listHidroponik = ArrayList<Hidroponikdb>()


        for (i in dataName.indices) {
            val Hidroponik = Hidroponikdb(
                namaHidroponik = dataName[i],
                gambarHidroponik = dataPhoto.getResourceId(i, -1),
                keteranganHidroponik = dataKet[i],
                tipe = dataTipe[i],
                bbakar = dataBbakar[i]
            )
            listHidroponik.add(Hidroponik)
        }
        dataPhoto.recycle()
        return listHidroponik
    }

    private fun showRecyclerList() {
        rvHidroponik.layoutManager = LinearLayoutManager(this)
        rvHidroponik.adapter = listAdapter

        listAdapter.setOnItemClickCallback(object : Adapter.OnItemClickCallback {
            override fun onItemClicked(data: Hidroponikdb) {
                showSelectedHidroponik(data)
            }

            override fun onShareClicked(data: Hidroponikdb) {
                shareHidroponik(data)
            }
        })
    }

    private fun showSelectedHidroponik(data: Hidroponikdb) {
        val intent = Intent(this, DetailHidroponik::class.java).apply {
            putExtra(DetailHidroponik.EXTRA_NAMA, data.namaHidroponik)
            putExtra(DetailHidroponik.EXTRA_GAMBAR, data.gambarHidroponik)
            putExtra(DetailHidroponik.EXTRA_KETERANGAN, data.keteranganHidroponik)
            putExtra(DetailHidroponik.EXTRA_TIPE, data.tipe)
            putExtra(DetailHidroponik.EXTRA_BBAKAR, data.bbakar)
        }
        startActivity(intent)
    }

    private fun shareHidroponik(data: Hidroponikdb) {
        val bitmap = BitmapFactory.decodeResource(resources, data.gambarHidroponik)
        val file = saveBitmapToFile(bitmap)
        file?.let {
            val fileUri = FileProvider.getUriForFile(this, "$packageName.provider", it)
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_STREAM, fileUri)
                type = "image/png"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Bagikan gambar menggunakan"))
        }
    }

    private fun saveBitmapToFile(bitmap: Bitmap): File? {
        val file = File(externalCacheDir, "shared_image.png")
        return try {
            FileOutputStream(file).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }
            file
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

}
