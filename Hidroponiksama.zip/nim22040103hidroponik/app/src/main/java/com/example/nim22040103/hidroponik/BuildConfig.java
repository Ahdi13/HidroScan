package com.example.nim22040103.hidroponik;

public class BuildConfig {


    public static String apiKey = "AIzaSyDhw9vGAn32Azb_nTxwUiosOxir603w9G4";
}
