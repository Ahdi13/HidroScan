package com.example.nim22040103.hidroponik

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Hidroponikdb(
    val namaHidroponik: String,
    val gambarHidroponik: Int,
    val keteranganHidroponik: String,
    val tipe: String,
    val bbakar: String
): Parcelable
