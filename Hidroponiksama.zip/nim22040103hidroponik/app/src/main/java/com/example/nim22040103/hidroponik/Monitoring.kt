package com.example.nim22040103.hidroponik

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.nim22040103.hidroponik.databinding.ActivityMonitoringBinding
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.*

class Monitoring : AppCompatActivity() {

    private lateinit var binding: ActivityMonitoringBinding
    private lateinit var auth: FirebaseAuth
    private val handler = Handler()
    private val runnable = object : Runnable {
        override fun run() {
            updateTime()
            handler.postDelayed(this, 1000) // Update setiap detik
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        // Inisialisasi binding dan Firebase Authentication
        binding = ActivityMonitoringBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = FirebaseAuth.getInstance() // Inisialisasi Firebase Authentication

        // Mulai update waktu
        handler.post(runnable)

        val fabAi: FloatingActionButton = findViewById(R.id.Ai)
        fabAi.setOnClickListener {
            val intent = Intent(this, Ai::class.java)
            startActivity(intent)
        }
        val database = FirebaseDatabase.getInstance().getReference("monitoring")

        database.child("pH").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ph = snapshot.getValue(Float::class.java)
                binding.tvPh.text = "${ph ?: "--"}"
            }
            override fun onCancelled(error: DatabaseError) {}
        })

// Ambil data TDS
        database.child("TDS").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val tds = snapshot.getValue(Float::class.java)
                binding.tvKualitasAir.text = "${tds?.toInt() ?: "--"} ppm"
            }
            override fun onCancelled(error: DatabaseError) {}
        })

// Ambil data Suhu
        database.child("Suhu").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val suhu = snapshot.getValue(Float::class.java)
                binding.tvSuhu.text = "${suhu ?: "--"} °C"
            }
            override fun onCancelled(error: DatabaseError) {}
        })

    }

    // Menampilkan menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_utama, menu)
        return true
    }



    // Menangani event klik pada item menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.list -> startActivity(Intent(this, MainActivity::class.java))
            R.id.About -> startActivity(Intent(this, About::class.java))
            R.id.CV -> startActivity(Intent(this, CV::class.java))
            R.id.Profile -> startActivity(Intent(this, ProfileActivity::class.java))
            R.id.Ai -> startActivity(Intent(this, Ai::class.java))
            R.id.logout -> logout() // Jika logout dipilih
        }
        return super.onOptionsItemSelected(item)
    }

    // Fungsi logout
    private fun logout() {
        auth.signOut() // Logout dari Firebase

        // Pindah ke LoginActivity dan hapus stack aktivitas sebelumnya
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish() // Menutup aktivitas Monitoring
    }

    // Fungsi untuk memperbarui waktu dan tanggal
    private fun updateTime() {
        val currentTime = System.currentTimeMillis()
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault())

        binding.clock.text = timeFormat.format(Date(currentTime)) // Update jam
        binding.date.text = dateFormat.format(Date(currentTime)) // Update tanggal
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable) // Hentikan update waktu saat aktivitas dihancurkan
    }
}
