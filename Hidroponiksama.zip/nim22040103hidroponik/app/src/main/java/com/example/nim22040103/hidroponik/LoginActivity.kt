package com.example.nim22040103.hidroponik

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.nim22040103.hidroponik.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        // Tombol login ditekan
        binding.continueBtn.setOnClickListener {
            val email = binding.email.text.toString().trim()
            val password = binding.password.text.toString().trim()

            // Validasi email kosong
            if (email.isEmpty()) {
                binding.email.error = "Email tidak boleh kosong"
                binding.email.requestFocus()
                return@setOnClickListener
            }

            // Validasi format email
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.email.error = "Format email tidak valid"
                binding.email.requestFocus()
                return@setOnClickListener
            }

            // Validasi password kosong
            if (password.isEmpty()) {
                binding.password.error = "Password tidak boleh kosong"
                binding.password.requestFocus()
                return@setOnClickListener
            }

            // Validasi panjang password minimal 6 karakter (sesuai Firebase)
            if (password.length < 6) {
                binding.password.error = "Password minimal 6 karakter"
                binding.password.requestFocus()
                return@setOnClickListener
            }

            // Login ke Firebase
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "signInWithEmail:success")
                        val intent = Intent(this, Monitoring::class.java)
                        startActivity(intent)
                        finish() // Biar user ga bisa balik ke login pake back
                    } else {
                        Log.w(TAG, "signInWithEmail:failure", task.exception)
                        Toast.makeText(
                            this,
                            "Login gagal: ${task.exception?.localizedMessage ?: "Cek email dan password"}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
        }

        // Pindah ke SignupActivity
        binding.move.setOnClickListener {
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
        }
    }

    // Auto-login kalau user udah pernah login sebelumnya
    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            startActivity(Intent(this, Monitoring::class.java))
            finish()
        }
    }
}
